
![Enviopack logo](https://www.enviopack.com/assets/enviopack.svg)

# ⚡️ EPic UI | El Design System de Envíopack 

EPic es la base visual y funcional de nuestra suite de productos. Nos permite diseñar experiencias consistentes, accesibles y eficientes, asegurando que cada elemento de la interfaz refleje nuestra identidad y facilite la interacción con nuestros distintos tipos de usuarios.
## 🤔 ¿Que nos aporta?
✅ Consistencia: Un lenguaje visual unificado que garantiza coherencia en todos los productos y plataformas.
✅ Eficiencia: Reduce el tiempo de desarrollo y diseño al reutilizar componentes bien definidos.
✅ Escalabilidad: Permite evolucionar el producto sin comprometer la calidad ni la usabilidad.
✅ Accesibilidad: Diseñado para cumplir con los estándares de accesibilidad y mejorar la experiencia de todos los usuarios.

## 📚 Librerias utilizadas

* React
* React router
* Panda Css
* Typescript
* Empaquetador Vite
* React testing library + Vitest

## ⚒️ Instalación EPic UI 

```sh
$ git clone git@bitbucket.org:enviopack/epic-ui.git
$ cd epic-ui
$ docker compose up --build -d
$ docker exec -ti epic /bin/bash
$ npm install
```

### 🐺 Instalación Husky 
Para mantener las buenas practicas de los gestionadores de paquetes utilizamos husky junto a otras herramientas como ESlint o Prettier. El proyecto trabaja con husky@9.x, para no tener problemas se recomienda ejecutarlo directamente en el contenedor de docker, o en su defecto usar node 20+ en local.

```sh
$ docker exec -ti epic /bin/bash
$ npm run prepare-husky
```

## 🏃‍♂️ Correr proyecto

```sh
$ docker exec -ti epic /bin/bash
$ npm run storybook
```

## 🧪 Testear proyecto
Para correr los test existentes:
```sh
$ docker exec -ti epic /bin/bash
$ npm run test
```
Para generar el reporte de cobertura:
```sh
$ docker exec -ti epic /bin/bash
$ npm run coverage
```


## Publicar en Npm

Antes de publicar algo se recuerda hacer un build del proyecto
```sh
 $ npm run build
```

Para publicar la librería primero hay que loguearse por consola a NPM (Onepassword)

```sh
 $ npm login
```

Despues de loguearse y haber hecho las modificaciones necesarias. Hay que modificar la versión del proyecto en el `package.json`. Utilizando nomenclatura [Semantic Versioning (SemVer).](https://semver.org/)

```
{
        ...,
        "version": "0.1.13",
        ...
}
```

Para publicar el proyecto hay que hacer un `npm publish`.

```sh
$ npm publish --access restricted
```
